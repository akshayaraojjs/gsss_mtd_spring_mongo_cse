package com.example.roombooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoombookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
